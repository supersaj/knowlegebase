#!/usr/bin/env python3
"""Validate a product knowledge base and generate its index.

Checks front matter of knowledge artifacts (business rules, ADRs, capabilities, ...),
product.yaml, and AGENTS.md size. Designed to run locally and in CI.

Also checks FINOS CALM architecture files (current / transition-NN / target) and
architecture/model/states.yaml, and can emit the derived knowledge graph (graph v0).

Usage:
  python validate_context.py --root <product repo>
         [--domain-root <domain context repo>] [--write-index] [--check-index]
         [--graph-out graph.json] [--skip-calm]
         [--json] [--today YYYY-MM-DD] [--agents-md-budget 150]

Exit code: 0 when there are no errors (warnings allowed), 1 otherwise.
Requires: Python 3.9+, PyYAML.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    sys.exit("PyYAML is required: pip install pyyaml")

TYPE_PREFIX = {
    "persona": "PER",
    "journey": "JRN",
    "use-case": "UC",
    "pain-point": "PAIN",
    "capability": "CAP",
    "quality-attribute": "NFR",
    "business-rule": "BR",
    "adr": "ADR",
    "glossary-term": "TERM",
    "runbook": "RB",
    "obligation": "OBL",
    "control": "CTL",
    "pattern": "PAT",
    "narrative": "NAR",
}
ID_RE = re.compile(r"^(PER|JRN|UC|PAIN|CAP|NFR|BR|ADR|TERM|RB|OBL|CTL|PAT|NAR)-[A-Z0-9]{2,10}-\d{3,}$")
ID_LIKE_RE = re.compile(r"^(PER|JRN|UC|PAIN|CAP|NFR|BR|ADR|TERM|RB|OBL|CTL|PAT|NAR)-")
STATUSES = {"proposed", "active", "deprecated", "superseded", "retired"}
CLASSIFICATIONS = {"public", "internal", "confidential"}
PROVENANCE_METHODS = {"human", "ai-draft", "extracted"}
RELATION_KEYS = {
    "implements", "governed_by", "applies_to", "decided_in", "depends_on",
    "verified_by_tests", "evidenced_by", "related_sdlc", "affects", "involves",
}
COMMON_REQUIRED = ["id", "type", "title", "status", "owner", "version", "review_by",
                   "classification", "provenance"]
TYPE_REQUIRED = {
    "business-rule": ["scope", "effective_from", "rule_source"],
    "adr": ["decision_date", "deciders"],
    "obligation": ["authority", "instrument", "effective_from"],
    "runbook": ["trigger"],
    "journey": ["persona"],
    "use-case": ["persona"],
    "pain-point": ["severity", "resolution"],
    "quality-attribute": ["measure", "target"],
}
PRODUCT_REQUIRED = ["id", "name", "owner", "lifecycle", "domain_context", "architecture",
                    "sdlc", "context_locations"]
SKIP_DIRS = {".git", "node_modules", "_bmad", "_bmad-output", "archive", ".venv",
             "venv", "dist", "build", "templates", "target"}
TYPE_ORDER = list(TYPE_PREFIX)


class Report:
    def __init__(self) -> None:
        self.errors: list[dict] = []
        self.warnings: list[dict] = []

    def error(self, path, msg):
        self.errors.append({"path": str(path), "message": msg})

    def warn(self, path, msg):
        self.warnings.append({"path": str(path), "message": msg})


def parse_front_matter(path: Path):
    text = path.read_text(encoding="utf-8", errors="replace")
    if not text.startswith("---"):
        return None
    parts = text.split("\n---", 1)
    if len(parts) < 2:
        return None
    raw = parts[0][3:]
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        return {"__yaml_error__": str(exc)}
    return data if isinstance(data, dict) else None


def to_date(value):
    if value in (None, ""):
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    try:
        return dt.date.fromisoformat(str(value))
    except ValueError:
        return "invalid"


def as_list(value):
    if value in (None, ""):
        return []
    return value if isinstance(value, list) else [value]


def iter_markdown(root: Path):
    for path in sorted(root.rglob("*.md")):
        rel = path.relative_to(root)
        if any(part in SKIP_DIRS for part in rel.parts[:-1]):
            continue
        yield path


def collect_artifacts(root: Path, report: Report | None):
    """Return {id: (path, front_matter)} for files that declare a known artifact type."""
    artifacts: dict[str, tuple[Path, dict]] = {}
    for path in iter_markdown(root):
        fm = parse_front_matter(path)
        if not fm:
            continue
        if "__yaml_error__" in fm:
            if report:
                report.error(path, f"front matter is not valid YAML: {fm['__yaml_error__']}")
            continue
        if fm.get("type") not in TYPE_PREFIX:
            continue
        art_id = str(fm.get("id", ""))
        if report and art_id in artifacts:
            report.error(path, f"duplicate id {art_id} (also in {artifacts[art_id][0]})")
            continue
        artifacts[art_id] = (path, fm)
    return artifacts


def load_codeowners(root: Path):
    for candidate in (root / "CODEOWNERS", root / ".github" / "CODEOWNERS",
                      root / "docs" / "CODEOWNERS"):
        if candidate.exists():
            return candidate.read_text(encoding="utf-8", errors="replace")
    return None


def check_artifact(art_id, path, fm, root, known_ids, today, codeowners, report):
    rel = path.relative_to(root)
    for key in COMMON_REQUIRED:
        if fm.get(key) in (None, ""):
            report.error(rel, f"missing required field '{key}'")

    a_type = fm.get("type")
    for key in TYPE_REQUIRED.get(a_type, []):
        if fm.get(key) in (None, "", []):
            report.error(rel, f"{a_type} missing required field '{key}'")

    if a_type == "pain-point":
        if fm.get("severity") not in (None, "low", "medium", "high", "critical"):
            report.error(rel, f"invalid severity '{fm.get('severity')}'")
        if fm.get("resolution") not in (None, "open", "planned", "mitigated", "resolved"):
            report.error(rel, f"invalid resolution '{fm.get('resolution')}'")
        if not as_list(fm.get("evidence")):
            report.warn(rel, "pain point has no evidence links")
    if a_type in ("journey", "use-case") and fm.get("persona") and str(fm.get("persona")) not in known_ids:
        report.error(rel, f"persona '{fm.get('persona')}' does not resolve")

    if not ID_RE.match(art_id):
        report.error(rel, f"id '{art_id}' does not match <TYPE>-<SCOPE>-<NNN>")
    elif not art_id.startswith(TYPE_PREFIX[a_type] + "-"):
        report.error(rel, f"id prefix does not match type '{a_type}' "
                          f"(expected {TYPE_PREFIX[a_type]}-)")
    if art_id and not path.name.startswith(art_id):
        report.warn(rel, f"file name should start with id '{art_id}'")

    status = fm.get("status")
    if status not in STATUSES:
        report.error(rel, f"invalid status '{status}'")

    classification = fm.get("classification")
    if classification == "restricted":
        report.error(rel, "restricted content is not allowed in the context layer; "
                          "link to the controlled system instead")
    elif classification not in CLASSIFICATIONS:
        report.error(rel, f"invalid classification '{classification}'")

    state = fm.get("state")
    if state is not None and not STATE_RE.match(str(state)):
        report.error(rel, f"state '{state}' must be current, target or transition-NN")

    version = fm.get("version")
    if version is not None and not isinstance(version, int):
        report.error(rel, "version must be an integer")

    # Supersession integrity
    superseded_by = fm.get("superseded_by")
    if status == "superseded":
        if not superseded_by:
            report.error(rel, "status 'superseded' requires 'superseded_by'")
        elif str(superseded_by) not in known_ids:
            report.error(rel, f"superseded_by '{superseded_by}' does not resolve")
    elif superseded_by:
        report.warn(rel, "superseded_by is set but status is not 'superseded'")
    for target in as_list(fm.get("supersedes")):
        if str(target) not in known_ids:
            report.error(rel, f"supersedes '{target}' does not resolve")

    # Provenance and verification
    prov = fm.get("provenance") or {}
    if not isinstance(prov, dict):
        report.error(rel, "provenance must be a mapping")
        prov = {}
    method = prov.get("method")
    if method not in PROVENANCE_METHODS:
        report.error(rel, f"invalid provenance.method '{method}'")
    if status == "active" and method in ("ai-draft", "extracted") and not prov.get("verified_by"):
        report.error(rel, f"active artifact with provenance '{method}' needs provenance.verified_by")
    if method in ("ai-draft", "extracted") and not as_list(prov.get("sources")):
        report.error(rel, "ai-draft or extracted artifacts must cite provenance.sources")

    # Dates
    review_by = to_date(fm.get("review_by"))
    if review_by == "invalid":
        report.error(rel, "review_by is not a valid ISO date")
    elif review_by and status == "active" and review_by < today:
        msg = f"review overdue since {review_by.isoformat()}"
        (report.error if a_type == "obligation" else report.warn)(rel, msg)
    effective_to = to_date(fm.get("effective_to"))
    if effective_to == "invalid":
        report.error(rel, "effective_to is not a valid ISO date")
    elif effective_to and status == "active" and effective_to < today:
        report.error(rel, f"active but effective_to {effective_to.isoformat()} has passed; "
                          "deprecate, retire or supersede it")
    effective_from = to_date(fm.get("effective_from"))
    if effective_from == "invalid":
        report.error(rel, "effective_from is not a valid ISO date")

    # Relations
    relations = fm.get("relations") or {}
    if not isinstance(relations, dict):
        report.error(rel, "relations must be a mapping")
        relations = {}
    for key, values in relations.items():
        if key not in RELATION_KEYS:
            report.error(rel, f"unknown relation '{key}' (allowed: {', '.join(sorted(RELATION_KEYS))})")
            continue
        for value in as_list(values):
            value = str(value)
            if ID_LIKE_RE.match(value) and value not in known_ids:
                severity = report.error if a_type in ("business-rule", "adr", "obligation") else report.warn
                severity(rel, f"relation {key} -> '{value}' does not resolve")
            elif ID_LIKE_RE.match(value):
                target_fm = known_ids[value]
                if target_fm and target_fm.get("status") in ("superseded", "retired") and status == "active":
                    report.warn(rel, f"relation {key} points to {target_fm.get('status')} '{value}'")

    # Ownership
    owner = str(fm.get("owner", ""))
    if codeowners is not None and owner:
        handle = owner.split(":", 1)[-1]
        if handle and handle not in codeowners:
            report.warn(rel, f"owner '{owner}' not found in CODEOWNERS")


def check_product_yaml(root: Path, report: Report):
    path = root / "product.yaml"
    if not path.exists():
        report.warn("product.yaml", "product.yaml not found (skip if this is a domain or enterprise repo)")
        return None
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        report.error("product.yaml", f"invalid YAML: {exc}")
        return None
    for key in PRODUCT_REQUIRED:
        if data.get(key) in (None, "", {}, []):
            report.error("product.yaml", f"missing required key '{key}'")
    domain = data.get("domain_context") or {}
    if isinstance(domain, dict) and domain and not domain.get("version"):
        report.error("product.yaml", "domain_context.version must pin a released version")
    sdlc = data.get("sdlc") or {}
    if isinstance(sdlc, dict) and sdlc and not sdlc.get("framework"):
        report.error("product.yaml", "sdlc.framework is required")
    locations = data.get("context_locations") or {}
    if isinstance(locations, dict):
        for name, loc in locations.items():
            if loc and not (root / str(loc)).exists():
                report.warn("product.yaml", f"context_locations.{name} path '{loc}' does not exist")
    return data


def check_agents_md(root: Path, budget: int, report: Report):
    path = root / "AGENTS.md"
    if not path.exists():
        report.warn("AGENTS.md", "AGENTS.md not found")
        return
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if len(lines) > budget:
        report.warn("AGENTS.md", f"{len(lines)} lines exceeds budget of {budget}; "
                                 "move detail into addressable files or skills")
    begins = [l for l in lines if l.strip().startswith("<!-- BEGIN ")]
    ends = [l for l in lines if l.strip().startswith("<!-- END ")]
    if len(begins) != len(ends):
        report.error("AGENTS.md", "unbalanced BEGIN/END section markers")


def build_index(root: Path, artifacts, product) -> str:
    title = product.get("name") if product else root.name
    out = [f"# Knowledge index: {title}", "",
           "<!-- GENERATED by validate_context.py. Do not edit by hand. -->", "",
           "Agents: read `active` entries by default. `proposed` entries are unapproved drafts.", ""]
    by_type: dict[str, list] = {}
    for art_id, (path, fm) in artifacts.items():
        by_type.setdefault(fm.get("type"), []).append((art_id, path, fm))
    for a_type in TYPE_ORDER:
        rows = by_type.get(a_type)
        if not rows:
            continue
        out += [f"## {a_type}", "", "| ID | Title | Status | Owner | Review by |",
                "|---|---|---|---|---|"]
        for art_id, path, fm in sorted(rows, key=lambda r: r[0]):
            rel = path.relative_to(root).as_posix()
            status = fm.get("status", "")
            if status == "superseded" and fm.get("superseded_by"):
                status = f"superseded by {fm['superseded_by']}"
            review = fm.get("review_by") or ""
            title_cell = str(fm.get("title", "")).replace("|", "\\|")
            out.append(f"| [{art_id}]({_rel_from_index(rel)}) | {title_cell} | {status} "
                       f"| {fm.get('owner', '')} | {review} |")
        out.append("")
    return "\n".join(out).rstrip() + "\n"


def _rel_from_index(rel: str) -> str:
    # INDEX.md lives in product-context/, so links go up one level.
    return "../" + rel


# ---------------------------------------------------------------------------
# CALM architecture models and architecture states
# ---------------------------------------------------------------------------

ID_FIND_RE = re.compile(r"\b(?:PER|JRN|UC|PAIN|CAP|NFR|BR|ADR|TERM|RB|OBL|CTL|PAT|NAR)-[A-Z0-9]{2,10}-\d{3,}\b")
STATE_RE = re.compile(r"^(current|target|transition-\d{2})$")
CALM_NODE_TYPES = {"actor", "ecosystem", "system", "service", "database", "network",
                   "ldap", "webclient", "data-asset"}
CALM_METADATA_KEYS = {"owner", "product", "classification", "business-rules", "adrs",
                      "capabilities", "rails", "messages", "nfrs", "lifecycle", "sunset",
                      "data-tags", "state"}
STATE_STATUSES = {"planned", "live", "retired"}


def _metadata_dicts(obj):
    meta = obj.get("metadata")
    if isinstance(meta, dict):
        return [meta]
    if isinstance(meta, list):
        return [m for m in meta if isinstance(m, dict)]
    return []


def _find_ids(value):
    """Yield every knowledge-base ID mentioned anywhere inside a JSON value."""
    if isinstance(value, str):
        yield from ID_FIND_RE.findall(value)
    elif isinstance(value, dict):
        for v in value.values():
            yield from _find_ids(v)
    elif isinstance(value, list):
        for v in value:
            yield from _find_ids(v)


def _relationship_edges(rel):
    """Return (edge_type, source, target) tuples for a CALM relationship."""
    rtype = rel.get("relationship-type") or {}
    edges = []
    if "connects" in rtype:
        c = rtype["connects"] or {}
        edges.append(("connects", (c.get("source") or {}).get("node"),
                      (c.get("destination") or {}).get("node")))
    if "interacts" in rtype:
        c = rtype["interacts"] or {}
        for n in as_list(c.get("nodes")):
            edges.append(("interacts", c.get("actor"), n))
    if "composed-of" in rtype:
        c = rtype["composed-of"] or {}
        for n in as_list(c.get("nodes")):
            edges.append(("contains", c.get("container"), n))
    if "deployed-in" in rtype:
        c = rtype["deployed-in"] or {}
        for n in as_list(c.get("nodes")):
            edges.append(("deployed_in", n, c.get("container")))
    return edges


def _resolve_id(ref, known, domain_given, rel, where, report):
    if ref in known:
        return
    if "-PAY-" in ref and not domain_given:
        report.warn(rel, f"{where}: '{ref}' not checked (pass --domain-root to resolve domain IDs)")
    else:
        report.error(rel, f"{where}: '{ref}' does not resolve to a knowledge artifact")


def check_calm_model(path: Path, root: Path, state: str, is_live: bool, known, domain_given,
                     today, report, graph):
    rel = path.relative_to(root)
    try:
        model = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        report.error(rel, f"invalid JSON: {exc}")
        return
    if not isinstance(model, dict):
        report.error(rel, "CALM architecture must be a JSON object")
        return

    node_ids: set[str] = set()
    for node in as_list(model.get("nodes")):
        uid = node.get("unique-id")
        if not uid:
            report.error(rel, "node without unique-id")
            continue
        if uid in node_ids:
            report.error(rel, f"duplicate node unique-id '{uid}'")
        node_ids.add(uid)
        if node.get("node-type") not in CALM_NODE_TYPES:
            report.warn(rel, f"node '{uid}' has non-standard node-type '{node.get('node-type')}'")
        graph.add_node(f"node:{uid}", kind=node.get("node-type"), name=node.get("name"),
                       state=state, source=str(rel))

    rel_ids: set[str] = set()
    for r in as_list(model.get("relationships")):
        rid = r.get("unique-id")
        if not rid:
            report.error(rel, "relationship without unique-id")
            continue
        if rid in rel_ids:
            report.error(rel, f"duplicate relationship unique-id '{rid}'")
        rel_ids.add(rid)
        edges = _relationship_edges(r)
        if not edges:
            report.error(rel, f"relationship '{rid}' has no recognised relationship-type")
        graph.add_node(f"relationship:{rid}", kind="relationship", name=r.get("description"),
                       state=state, source=str(rel))
        for etype, src, dst in edges:
            graph.add_edge(f"node:{src}", f"node:{dst}", etype, state=state, source=str(rel),
                           relationship=rid, protocol=r.get("protocol"))

    # Endpoint check once all nodes are known
    for r in as_list(model.get("relationships")):
        for etype, src, dst in _relationship_edges(r):
            for end in (src, dst):
                if not end or end not in node_ids:
                    report.error(rel, f"relationship '{r.get('unique-id')}' references unknown node '{end}'")

    # Flows
    for flow in as_list(model.get("flows")):
        fid = flow.get("unique-id", "?")
        seqs = []
        graph.add_node(f"flow:{fid}", kind="flow", name=flow.get("name"), state=state, source=str(rel))
        for t in as_list(flow.get("transitions")):
            rid = t.get("relationship-unique-id")
            if rid not in rel_ids:
                report.error(rel, f"flow '{fid}' references unknown relationship '{rid}'")
            seqs.append(t.get("sequence-number"))
            graph.add_edge(f"flow:{fid}", f"relationship:{rid}", "step", state=state,
                           source=str(rel), sequence=t.get("sequence-number"))
        if len(seqs) != len(set(seqs)):
            report.error(rel, f"flow '{fid}' has duplicate sequence numbers")

    # Metadata, controls and lifecycle on every element
    elements = [("architecture", model.get("unique-id", "architecture"), model)]
    elements += [("node", n.get("unique-id"), n) for n in as_list(model.get("nodes"))]
    elements += [("relationship", r.get("unique-id"), r) for r in as_list(model.get("relationships"))]
    elements += [("flow", f.get("unique-id"), f) for f in as_list(model.get("flows"))]
    for kind, eid, obj in elements:
        gid = {"node": f"node:{eid}", "flow": f"flow:{eid}",
               "relationship": f"relationship:{eid}"}.get(kind, f"architecture:{eid}")
        for meta in _metadata_dicts(obj):
            for key, value in meta.items():
                if key not in CALM_METADATA_KEYS:
                    report.warn(rel, f"{kind} '{eid}': non-standard metadata key '{key}'")
                for ref in _find_ids(value):
                    _resolve_id(ref, known, domain_given, rel, f"{kind} '{eid}' metadata {key}", report)
                    graph.add_edge(gid, ref, key.replace("-", "_"), state=state, source=str(rel))
            if meta.get("lifecycle") == "transitional":
                sunset = to_date(meta.get("sunset"))
                if not sunset or sunset == "invalid":
                    report.error(rel, f"{kind} '{eid}' is transitional but has no valid sunset date")
                elif sunset < today:
                    (report.error if is_live else report.warn)(
                        rel, f"{kind} '{eid}' passed its sunset date {sunset.isoformat()}")
        controls = obj.get("controls") or {}
        if isinstance(controls, dict):
            for cname, control in controls.items():
                for ref in _find_ids(control):
                    _resolve_id(ref, known, domain_given, rel, f"{kind} '{eid}' control {cname}", report)
                    etype = "satisfies" if ref.startswith("OBL-") else "controlled_by"
                    graph.add_edge(gid, ref, etype, state=state, source=str(rel), control=cname)


def check_states(root: Path, product, known, domain_given, today, report, graph):
    arch = (product or {}).get("architecture") or {}
    model_dir = root / str(arch.get("model", "architecture/model"))
    if not model_dir.exists():
        report.warn(str(model_dir.relative_to(root)), "architecture model folder not found")
        return
    models = sorted(model_dir.glob("*.architecture.json"))
    if not models:
        report.warn(str(model_dir.relative_to(root)), "no CALM *.architecture.json files found")
        return

    states_path = model_dir / "states.yaml"
    listed: dict[str, dict] = {}
    if states_path.exists():
        try:
            data = yaml.safe_load(states_path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError as exc:
            report.error(states_path.relative_to(root), f"invalid YAML: {exc}")
            data = {}
        live = []
        for entry in as_list(data.get("states")):
            sid = str(entry.get("id", ""))
            srel = states_path.relative_to(root)
            if not STATE_RE.match(sid):
                report.error(srel, f"state id '{sid}' must be current, target or transition-NN")
            if entry.get("status") not in STATE_STATUSES:
                report.error(srel, f"state '{sid}' has invalid status '{entry.get('status')}'")
            if entry.get("status") == "live":
                live.append(entry)
            file_name = entry.get("file")
            if not file_name or not (model_dir / file_name).exists():
                report.error(srel, f"state '{sid}' file '{file_name}' not found")
            for ref in as_list(entry.get("approved_by")):
                _resolve_id(str(ref), known, domain_given, srel, f"state '{sid}' approved_by", report)
            window = entry.get("window") or {}
            end = to_date(window.get("to")) if isinstance(window, dict) else None
            if entry.get("status") == "planned" and end and end != "invalid" and end < today:
                report.warn(srel, f"state '{sid}' planned window ended {end.isoformat()}; update the plan")
            listed[str(file_name)] = entry
        if len(live) != 1:
            report.error(states_path.relative_to(root), f"exactly one state must be live (found {len(live)})")
        elif live[0].get("file") != "current.architecture.json":
            report.error(states_path.relative_to(root), "the live state's file must be current.architecture.json")
    elif len(models) > 1:
        report.error(model_dir.relative_to(root), "several architecture states exist but states.yaml is missing")

    if not (model_dir / "current.architecture.json").exists():
        report.error(model_dir.relative_to(root), "current.architecture.json is required")

    for model in models:
        state = model.name.replace(".architecture.json", "")
        if not STATE_RE.match(state):
            report.error(model.relative_to(root), "file name must be current, target or transition-NN .architecture.json")
        if listed and model.name not in listed:
            report.error(model.relative_to(root), "architecture file is not listed in states.yaml")
        check_calm_model(model, root, state, state == "current", known, domain_given, today, report, graph)


class Graph:
    """Derived knowledge graph (graph v0). Nodes and typed edges with provenance."""

    def __init__(self) -> None:
        self.nodes: dict[str, dict] = {}
        self.edges: list[dict] = []

    def add_node(self, nid, **attrs):
        node = self.nodes.setdefault(nid, {"id": nid, "states": []})
        state = attrs.pop("state", None)
        if state and state not in node["states"]:
            node["states"].append(state)
        node.update({k: v for k, v in attrs.items() if v is not None})

    def add_edge(self, src, dst, etype, **attrs):
        self.edges.append({"from": src, "to": dst, "type": etype,
                           **{k: v for k, v in attrs.items() if v is not None}})

    def to_json(self):
        return {"generated_by": "validate_context.py", "nodes": list(self.nodes.values()),
                "edges": self.edges}


def add_artifacts_to_graph(graph: Graph, artifacts, root: Path):
    for art_id, (path, fm) in artifacts.items():
        rel = path.relative_to(root).as_posix()
        graph.add_node(art_id, kind=fm.get("type"), name=fm.get("title"),
                       status=fm.get("status"), source=rel, state=fm.get("state", "current"))
        relations = fm.get("relations") if isinstance(fm.get("relations"), dict) else {}
        for key, values in relations.items():
            for value in as_list(values):
                target = str(value)
                if ":" in target and not ID_LIKE_RE.match(target):
                    target = "node:" + target.split(":", 1)[1]
                graph.add_edge(art_id, target, key, source=rel)
        for target in as_list(fm.get("supersedes")):
            graph.add_edge(art_id, str(target), "supersedes", source=rel)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", required=True, help="product (or domain) repository root")
    parser.add_argument("--domain-root", help="payments domain-context repo, for resolving shared IDs")
    parser.add_argument("--write-index", action="store_true", help="write product-context/INDEX.md")
    parser.add_argument("--check-index", action="store_true", help="fail if INDEX.md is stale")
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument("--today", help="override today's date (YYYY-MM-DD) for reproducible runs")
    parser.add_argument("--agents-md-budget", type=int, default=150)
    parser.add_argument("--graph-out", help="write the derived knowledge graph (graph v0) as JSON")
    parser.add_argument("--skip-calm", action="store_true", help="skip CALM model and states checks")
    args = parser.parse_args(argv)

    root = Path(args.root).resolve()
    today = dt.date.fromisoformat(args.today) if args.today else dt.date.today()
    report = Report()

    artifacts = collect_artifacts(root, report)
    known: dict[str, dict | None] = {k: fm for k, (_, fm) in artifacts.items()}
    if args.domain_root:
        domain_artifacts = collect_artifacts(Path(args.domain_root).resolve(), None)
        for k, (_, fm) in domain_artifacts.items():
            known.setdefault(k, fm)

    codeowners = load_codeowners(root)
    for art_id, (path, fm) in artifacts.items():
        check_artifact(art_id, path, fm, root, known, today, codeowners, report)

    product = check_product_yaml(root, report)
    check_agents_md(root, args.agents_md_budget, report)

    graph = Graph()
    add_artifacts_to_graph(graph, artifacts, root)
    if not args.skip_calm and product is not None:
        check_states(root, product, known, bool(args.domain_root), today, report, graph)
    if args.graph_out:
        Path(args.graph_out).write_text(json.dumps(graph.to_json(), indent=2), encoding="utf-8")

    index_path = root / "product-context" / "INDEX.md"
    index_text = build_index(root, artifacts, product)
    if args.write_index:
        index_path.parent.mkdir(parents=True, exist_ok=True)
        index_path.write_text(index_text, encoding="utf-8")
    elif args.check_index:
        current = index_path.read_text(encoding="utf-8") if index_path.exists() else ""
        if current != index_text:
            report.error("product-context/INDEX.md", "index is stale; run with --write-index")

    summary = {"artifacts": len(artifacts), "errors": len(report.errors),
               "warnings": len(report.warnings)}
    if args.json:
        print(json.dumps({"summary": summary, "errors": report.errors,
                          "warnings": report.warnings}, indent=2))
    else:
        for item in report.errors:
            print(f"ERROR   {item['path']}: {item['message']}")
        for item in report.warnings:
            print(f"WARNING {item['path']}: {item['message']}")
        print(f"\n{summary['artifacts']} artifacts, {summary['errors']} errors, "
              f"{summary['warnings']} warnings")
    return 1 if report.errors else 0


if __name__ == "__main__":
    sys.exit(main())
