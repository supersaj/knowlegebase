# Retrieval, Catalog and Graph

Four mechanisms, each for a different question. Do not collapse them into one technology.

| Mechanism | Question it answers | Source of truth? |
|---|---|---|
| Files in Git (Markdown + front matter, contracts, model) | What do we know and why? | Yes, for durable knowledge |
| Catalog (e.g. Backstage) | What exists, who owns it, what depends on what? | Yes, only for metadata it is designated to own; otherwise an aggregator |
| Graph | How are things related across products and tiers? | No. Derived. |
| Search / RAG index | Where is the relevant unstructured material? | No. Derived. |
| MCP / APIs | What is true right now, and what can I do? | Proxies the system of record |

## 1. Retrieval order for agents

1. **Orient**: `AGENTS.md` → `product.yaml` → generated `product-context/INDEX.md`.
2. **Exact lookup**: follow IDs and paths (rules, ADRs, obligations, contracts). Coding agents
   are good at agentic file search; a clean ID scheme plus an index beats embedding search for
   authoritative content.
3. **Structured queries**: catalog or graph for ownership, dependencies, consumers.
4. **Live state**: MCP/API for deployments, incidents, tickets, runtime topology.
5. **Semantic search**: only for large unstructured history (old designs, post-mortems,
   Confluence archives). Results are treated as leads, then confirmed against authoritative files.
6. **Assemble minimal context**: include what the task needs; cite IDs.

The original plan's "classify task → graph traversal → retrieve" pipeline is a reasonable end
state for a central platform, but most value arrives earlier from steps 1 to 4. Build the
pipeline only when evaluation shows agents failing to find cross-product context.

## 2. When to introduce each component

| Component | Introduce when | Not before |
|---|---|---|
| Front matter + validator + INDEX.md | Day one | — |
| Domain-context repo | Two or more products share rules or mappings | — |
| Catalog descriptors (`catalog-info.yaml`) | The org runs a catalog, or products need cross-repo ownership lookup | — |
| MCP servers for Jira/Git/CI/observability/catalog | Agents need live state; approved servers exist | Security review done |
| Graph schema (node types, edge vocabulary, ID rules) | Day one | — |
| Graph v0 (JSON built by the validator in CI) | First product baseline exists | — |
| Graph database | Multi-hop golden questions fail on graph v0, more than ~5 products onboarded, impact analysis becomes a change-approval step, or runtime topology must join design-time data | Front matter and architecture models are consistent and validated across products |
| Semantic index | Unstructured archives are large and searched often | Access controls on the index match the sources |

## 3. Building the graph

- Graph v0: `validate_context.py --graph-out graph.json` emits nodes and typed edges from front
  matter `relations` and the architecture model (elements, relationships, flows, controls, linked IDs).
- Extract deterministically from: architecture model files (all states, tagged by state), front
  matter `relations`, `product.yaml`, catalog descriptors, OpenAPI/AsyncAPI, IaC and deployment manifests.
- LLM extraction is allowed only to propose edges; proposals are reviewed like any other artifact.
- Every edge carries provenance: source path or system, extraction method, extracted-at time,
  source commit or version.
- Rebuild on merge. Never edit the graph by hand. If a relationship is wrong, fix the source.
- Keep three logical layers: product (within one product), enterprise (across products, domains,
  teams), runtime (deployments and live dependencies, refreshed from systems of record).
- Model only relationships that answer real questions. Thousands of low-value edges make traversal noisy.

## 4. Architecture as code

- Architecture is described with the C4 model, stored as one model per state in the department format
  (FINOS CALM, see `calm-conventions.md`). C4 diagrams are generated views.
- Diagrams are generated views. Mermaid or PlantUML may be used for sequence and flow diagrams
  that the model does not cover, stored as source, rendered in CI.
- Architecture as code (structure, relationships, constraints, intent) is distinct from
  infrastructure as code (executable configuration). Link them; do not merge them.
- Fitness functions in CI can check the code against the model and ADRs (for example, forbidden
  dependencies, required idempotency middleware). These are the strongest drift detectors.
