# CALM Conventions (payments department)

FINOS CALM is the department's architecture model. These conventions keep models consistent
across products so they can be validated, compared across states, and joined with the rest of
the knowledge base. Pin the CALM schema version in `product.yaml` (`architecture.calm_schema`)
and upgrade deliberately.

## 1. Files

| File | Purpose |
|---|---|
| `architecture/model/current.architecture.json` | As-is production architecture (always present) |
| `architecture/model/transition-NN.architecture.json` | Interim states, numbered in delivery order |
| `architecture/model/target.architecture.json` | Approved end state (omit when equal to current) |
| `architecture/model/states.yaml` | Ordered index of states (see section 7) |
| Domain repo `calm/patterns/*.pattern.json` | Approved patterns products validate against |
| Domain repo `calm/controls/CTL-PAY-*.requirement.json` | Control requirement definitions |
| Domain repo `calm/shared-nodes/*.json` | Shared systems (rails, sanctions screening, funds control) referenced by products |

## 2. Identity

- `unique-id` = catalog slug, lowercase kebab-case: `rtp-gateway` ↔ `component:rtp-gateway`.
- The same `unique-id` keeps its meaning in every state file. A replaced component gets a new ID; it is not renamed in place.
- Relationship IDs describe the interaction: `payment-api-screens-parties`, not `rel-1`.

## 3. Node types (C4 mapping)

| C4 concept | CALM `node-type` |
|---|---|
| Person | `actor` |
| Software system (ours or external) | `system` |
| Container: service, API, batch job, worker | `service` |
| Container: database, ledger store | `database` |
| Container: UI | `webclient` |
| Deployment environment, zone | `network`, `ecosystem` |
| Data set of note (e.g. payment ledger) | `data-asset` |

Structure with relationships: `composed-of` (system → containers → components), `connects`
(technical call or message, with `protocol`), `interacts` (actor → system), `deployed-in`
(node → environment). Model components only where they explain a decision or a control.

## 4. Metadata keys (use exactly these)

| Key | On | Value |
|---|---|---|
| `owner` | architecture, system, service | `team:<name>` from CODEOWNERS |
| `product` | architecture | product code (`PMTHUB`) |
| `classification` | node | `public`, `internal`, `confidential` |
| `business-rules` | node, relationship, flow | list of `BR-*` |
| `adrs` | any | list of `ADR-*` |
| `capabilities` | flow, system | list of `CAP-*` |
| `rails` | node, flow | domain rail IDs (`rtp`, `fedwire`, `fednow`, `ach`, `chips`, `swift`) |
| `messages` | relationship, interface | message types from the domain message catalog |
| `nfrs` | node, flow | list of `NFR-*` quality attributes the element must meet |
| `lifecycle` | node, relationship | `stable` (default), `transitional`, `retiring` |
| `sunset` | transitional elements | ISO date by which it must be gone |
| `data-tags` | node | `pii`, `npi`, `pci`, `sanctions-data` (drives controls and reviews) |

Values are IDs, never copied rule or policy text.

## 5. Controls

- Attach controls where they are enforced: the relationship (e.g. screening call), the node (e.g. encryption at rest), or the flow (e.g. dual authorization before release).
- `requirement-url` points to the domain control definition (`CTL-PAY-*`).
- `config` names the obligation and product settings: `{ "obligation": "OBL-PAY-020", "screening-point": "pre-release" }`.
- Every `data-tags` value implies required controls, defined in the domain patterns.

## 6. Flows

- One flow per critical payment journey: at least initiation, screening, funds control, release to rail, status handling, returns, repair.
- Transitions reference existing relationship IDs in sequence.
- Flow metadata lists `capabilities`, `business-rules` and `rails`.
- Flows replace hand-drawn sequence diagrams for these journeys; use Mermaid only for detail below the model's level.

## 7. States (`states.yaml`)

```yaml
product: PMTHUB
states:
  - id: current
    file: current.architecture.json
    status: live
    since: 2026-06-30
  - id: transition-01
    file: transition-01.architecture.json
    status: planned                 # planned | live | retired
    window: { from: 2026-11-15, to: 2027-03-31 }
    delivers: [EPIC-PMTHUB-12]      # SDLC references
    approved_by: [ADR-PMTHUB-031]
    exit_criteria:
      - "Parallel run shows zero unexplained reconciliation breaks for 20 business days"
  - id: target
    file: target.architecture.json
    status: planned
    approved_by: [ADR-PMTHUB-030]
```

- Exactly one `live` state, and its file is `current.architecture.json`.
- At go-live: copy the delivered state into `current.architecture.json`, mark it `live`, delete its transition file (Git keeps history), update `since`.
- Transitional elements whose `sunset` has passed fail CI.

## 8. CI and authoring

- **CI:** `calm validate` against the declared pattern(s); `validate_context.py` checks IDs inside CALM files, unique IDs, flow transitions and `states.yaml`; views regenerated (`calm docify` or the organization's renderer).
- **Authoring:** use the CALM VS Code extension and its AI assistant, or an agent with this skill; review the diff, not the JSON by hand. Start from `assets/templates/architecture.json`.
- **Graph:** nodes and relationships are extracted directly into the knowledge graph; metadata IDs become edges to rules, ADRs, obligations and capabilities.
