# Artifact Schemas

Every durable artifact is a Markdown file with YAML front matter. The front matter is the
contract that the validator, catalog, graph and indexes read. The body is for humans and
agents. Keep one concept per file so each can be addressed, reviewed and superseded alone.

## 1. ID conventions

Format: `<TYPE>-<SCOPE>-<NNN>` where `SCOPE` is the product code (2 to 10 uppercase letters or
digits) or `PAY` for the payments domain tier, and `NNN` is at least three digits.

| Prefix | Artifact | Typical home |
|---|---|---|
| `PER` | Persona (customer, operator, partner) | product `product-context/personas/` |
| `JRN` | Customer or operator journey | product `product-context/journeys/` |
| `UC` | Use case | product `product-context/use-cases/` |
| `PAIN` | Pain point | product `product-context/pain-points/` |
| `CAP` | Capability | product `product-context/capabilities/` |
| `BR` | Business rule | product `product-context/business-rules/` or domain `rules/` |
| `ADR` | Architecture decision record | `architecture/decisions/` (product or domain) |
| `NFR` | Quality attribute (availability, latency, throughput, security, resilience) | product `product-context/quality-attributes/` |
| `TERM` | Glossary term | `glossary/` |
| `RB` | Runbook / operational procedure | product `operations/runbooks/` |
| `OBL` | Regulatory or scheme obligation | domain `obligations/` |
| `CTL` | Control (or pointer to GRC control) | domain `controls/` |
| `PAT` | Approved architecture pattern | domain `patterns/` |
| `NAR` | Architecture narrative | `architecture/narratives/` |

Examples: `BR-PMTHUB-042`, `ADR-PMTHUB-024`, `OBL-PAY-007`, `TERM-PAY-015`.

Rules:
- IDs are permanent. Never reuse or renumber. A changed rule gets a new version, or a new ID that supersedes the old one when its meaning changes.
- Systems, components, APIs and teams use catalog entity references, not these IDs (for example `component:payment-api`, `api:payment-api-v2`, `team:payments-hub`).
- File name = `<ID>-<short-slug>.md` so humans and agents can find it by either.

## 2. Common front matter (all types)

```yaml
---
id: BR-PMTHUB-042
type: business-rule          # persona | journey | use-case | pain-point | capability | business-rule
                             # | quality-attribute | adr | glossary-term | runbook
                             # | obligation | control | pattern | narrative
title: Counterparty validation before RTP authorization
status: active               # proposed | active | deprecated | superseded | retired
owner: team:payments-hub     # must resolve to a CODEOWNERS team
version: 3                   # integer, bump on any meaning change
review_by: 2027-03-31        # next scheduled review (see cadence table)
classification: internal     # public | internal | confidential ; "restricted" is not allowed in the context layer
supersedes: [BR-PMTHUB-017]  # optional
superseded_by:               # required when status is superseded
provenance:
  method: human              # human | ai-draft | extracted
  sources:                   # evidence: paths, contract files, PRs, policy references
    - product-context/prd-archive/epic-12.md
  verified_by: jdoe          # required when method is ai-draft or extracted and status is active
  verified_at: 2026-09-20
relations:                   # controlled vocabulary, see section 4
  implements: [CAP-PMTHUB-003]
  governed_by: [OBL-PAY-011]
  applies_to: [component:rtp-gateway]
tags: [rtp, validation]
state: current               # optional: current (default) | transition-NN | target
---
```

`state` marks knowledge that applies only to a future architecture state. Pair it with a future
`effective_from`. When that state goes live, set `state: current` (or remove the field).

## 3. Type-specific fields and body sections

### Persona (`persona`)

Body: who they are, goals, context of use, channels, what success looks like for them.
No real customer names or data; personas are archetypes.

### Journey (`journey`)

Additional front matter: `persona` (a `PER-*`), `state` (`current` default, or `target`).
Body: numbered stages; for each: what the persona does, touchpoint or channel, system behaviour
(C4 element IDs), and pain points (`PAIN-*`). A target journey states which ADR or state delivers it.

### Use case (`use-case`)

Additional front matter: `persona`. Relations: `implements` → `CAP-*`, `depends_on` → `BR-*`.
Body: goal, trigger, preconditions, main flow, alternate and failure flows, postconditions.

### Pain point (`pain-point`)

Additional front matter:
```yaml
severity: high               # low | medium | high | critical
resolution: open             # open | planned | mitigated | resolved
evidence:                    # links to research, incidents, complaints, metrics (never pasted content)
  - <link>
```
Relations: `affects` → `JRN-*`, `UC-*`, `PER-*`; `related_sdlc` → the epic that addresses it.
Body: the problem in the persona's words (summarized), impact (time, cost, risk, customer effect),
frequency, current workaround. When the fix goes live set `resolution: resolved`.

### Quality attribute (`quality-attribute`)

Additional front matter: `measure` (e.g. "p99 end-to-end latency"), `target` (e.g. "under 5 s"),
`scope` (flows or C4 elements). Body: rationale, how it is measured, current value (linked to
the observability source, not copied).

### Business rule (`business-rule`)

Additional front matter:
```yaml
scope: "RTP credit transfers, outbound"
effective_from: 2026-03-01
effective_to:                # set when a scheme change retires it
rule_source: policy          # policy | regulation | scheme-rule | product-decision | contract
```
Body sections:
1. **Rule** — one or two precise sentences. Use EARS style where it helps: "When `<trigger>`, the system shall `<response>`."
2. **Rationale** — why the rule exists.
3. **Exceptions** — explicit and exhaustive, or "none".
4. **Examples** — synthetic only.
5. **Verification** — tests or controls that prove it (`relations.verified_by_tests`).

### ADR (`adr`)

MADR-aligned. Additional front matter:
```yaml
decision_date: 2026-05-14
deciders: [team:payments-hub, role:chief-architect]
```
Body sections: Context and problem · Decision drivers · Considered options · Decision ·
Consequences (positive, negative, follow-ups) · Compliance or risk impact · Links.

ADRs are immutable once `active` (accepted). Only `status`, `superseded_by` and `review_by`
may change afterwards. A new decision creates a new ADR with `supersedes`.

### Capability (`capability`)

Body: purpose, actors, inputs/outputs at business level, rails and message types involved
(by domain ID), boundaries, related rules and components.

### Glossary term (`glossary-term`)

Additional: `synonyms`, `not_to_be_confused_with`, `domain_term` (the domain `TERM-PAY-*`
this narrows, if any). A product defines a term only when it genuinely differs from the domain term.

### Runbook (`runbook`)

Additional: `trigger`, `severity`, `systems` (catalog refs). Body: detection, diagnosis steps,
recovery steps, reconciliation after recovery, escalation, verification. Commands must be
tested; no secrets or production identifiers.

### Obligation (`obligation`, domain tier)

Additional: `authority` (e.g. Federal Reserve, Nacha, The Clearing House, FinCEN, OFAC),
`instrument` (regulation, operating circular or rules document and section),
`applies_to_rails`, `effective_from`, `effective_to`, `grc_ref` (ID in the bank's GRC system).
Body: plain-language summary of the obligation in your own words, what it requires of systems,
evidence expected. Do not paste scheme rule text; link to the licensed source.

### Control (`control`, domain tier)

Usually a pointer: `grc_ref`, `control_type` (preventive | detective), `automated` (bool),
`evidence`. The GRC system stays authoritative.

## 4. Relation vocabulary

Use only these keys under `relations:`. Values are lists of IDs or catalog refs.

| Key | Meaning |
|---|---|
| `implements` | this artifact realizes a capability or requirement |
| `governed_by` | this is constrained by an obligation, policy or rule |
| `applies_to` | components, APIs or systems the artifact constrains |
| `decided_in` | the ADR that made this so |
| `depends_on` | knowledge or component dependency |
| `verified_by_tests` | test paths or test IDs |
| `evidenced_by` | control evidence, review records |
| `related_sdlc` | SDLC artifacts (epic, PRD, spec) that introduced or changed it |
| `affects` | pain point → journeys, use cases or personas it hurts |
| `involves` | journey or use case → personas taking part |

Do not add `related_to`. If no typed relation fits, the link is probably not worth keeping.

## 5. Status lifecycle

```
proposed ──approve──> active ──> deprecated ──> retired
                        │
                        └──replace──> superseded (superseded_by: <new id>)
```

- Only a CODEOWNER review moves `proposed` to `active`.
- `superseded` requires `superseded_by` pointing to an existing, non-retired artifact.
- Agents read `active` by default. `proposed` may be read with an explicit caveat.

## 6. Review cadence defaults

| Type | Default `review_by` | Also review when |
|---|---|---|
| Business rule | 12 months | Scheme or policy change, related incident |
| Obligation | 12 months or scheme release cycle | Any rulebook, circular or regulation update |
| ADR | none (immutable); 24 months relevance check | Architecture change touching it |
| Capability | 12 months | Scope change |
| Architecture narrative | 6 months | Any container or integration change |
| Runbook | 6 months | After every use in an incident |
| Glossary term | 24 months | Conflict found |
| Persona, journey, use case | 12 months | New research, channel change, go-live of a target journey |
| Pain point | 6 months while open | New evidence; epic delivered |
| Quality attribute | 12 months | Incident, capacity change, new scheme requirement |

## 7. product.yaml

See `assets/templates/product.yaml`. Required keys: `id`, `name`, `owner`, `lifecycle`,
`domain_context` (repo and pinned version), `architecture` (model folder and pinned model-format version),
`sdlc.framework`, `sdlc.artifact_locations`, `context_locations`, `systems_of_record`
(where live facts come from).
