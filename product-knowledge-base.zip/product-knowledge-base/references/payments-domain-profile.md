# Payments Domain Profile

Knowledge in this file belongs in the **payments domain-context repository**, shared by every
product and referenced by ID and pinned version. Products do not copy it.

Compliance, legal and the bank's GRC system remain authoritative for obligations and controls.
The domain repo holds an engineering-oriented summary in its own words plus references. It is
not legal advice and must be validated with compliance owners.

## 1. What the domain tier should contain

| Area | Content | Authoritative source | Notes |
|---|---|---|---|
| Rails | Per rail: purpose, participants, message set, settlement model, operating hours model, limits model, return/recall model | Scheme rulebooks, operating circulars | Store the model and references; operational values (actual cut-off times, limits) come from configuration or the system of record |
| Message catalog | Message types and versions in use per rail, usage guidelines in force | Scheme rulebooks and usage guidelines | Versions pinned per rail; scheme standards releases are change events |
| Mappings | Internal canonical payment model ↔ each rail's message formats, field-level rules | Domain repo (owned by domain architects) | Machine-readable (YAML/CSV) plus tests; a high-value, frequently reused asset |
| Code sets | Status reasons, return reasons (e.g. Nacha return codes, scheme reason codes), rejection reasons with internal meaning and handling | External code set publications + internal handling rules | Record internal handling as `BR-PAY-*` |
| Calendars and cut-offs | Definitions and where to get current values | Calendar service / configuration | Never hard-code dates in prose |
| Obligation register | `OBL-PAY-*` entries | GRC system | See section 2 |
| Controls | `CTL-PAY-*` pointers | GRC system | Link to evidence, not copies |
| Patterns | `PAT-PAY-*`: idempotency and duplicate detection, end-to-end tracking IDs (e.g. UETR), saga/compensation, funds control, sanctions screening placement, exception/repair queues, reconciliation, cut-over and parallel run | Domain ADRs | Each pattern names its ADR |
| Glossary | `TERM-PAY-*` | Domain repo | Products narrow, never redefine silently |

## 2. Obligation register seed (verify with compliance)

Typical instruments a US payments department maps. Record each as an `OBL-PAY-*` artifact with
`authority`, `instrument` and `grc_ref`, summarizing systems impact in your own words.

| Area | Instruments to consider |
|---|---|
| Fedwire Funds | Regulation J (12 CFR 210, subpart B), UCC Article 4A, Federal Reserve Operating Circular 6 |
| FedNow | Regulation J (subpart C), Federal Reserve Operating Circular 8 |
| CHIPS | CHIPS Rules and Administrative Procedures, UCC Article 4A |
| RTP | The Clearing House RTP Operating Rules |
| ACH | Nacha Operating Rules, Federal Reserve Operating Circular 4 (FedACH), Regulation E for consumer entries |
| Consumer transfers | Regulation E (12 CFR 1005), including remittance transfer requirements where applicable |
| Cross-border / SWIFT | SWIFT rulebook and standards releases, SWIFT Customer Security Programme |
| Sanctions | OFAC regulations (31 CFR Chapter V) and bank sanctions policy |
| BSA/AML | Funds transfer recordkeeping and travel rule (31 CFR 1010.410), bank AML policy |
| Privacy and data | GLBA and bank data classification policy; PCI DSS only if card data is in scope |
| Operational resilience | Bank BCP/DR, third-party risk, and change-management policies (often SOX ITGC-relevant) |

Each obligation should link to:
- the business rules that implement it (`BR-*` with `governed_by: [OBL-...]`),
- the controls that evidence it (`CTL-*`),
- the products and components it applies to.

That chain is what lets an agent answer "what must not break if I change this?" and lets an
auditor follow rule → code → test → evidence.

## 3. Effective dating is mandatory

Payments rules change on scheme calendars (rulebook updates, standards releases, operating
circular revisions, migration deadlines). Every obligation and domain rule carries
`effective_from` and, when known, `effective_to`. Agents must evaluate rules against the date
the behaviour will be live, not today's date, when planning a change.

## 4. Starter domain skills (aim for 5 to 10 first)

| Skill | What it does |
|---|---|
| `message-change` | Adds or changes a message or field: checks catalog version, mapping, code sets, validation rules, tests, affected products |
| `new-business-rule` | Drafts a `BR-*` with EARS wording, scope, obligation links, tests, and routes to the owner |
| `adr-writer` | Drafts a MADR-style ADR with payments decision drivers (latency, finality, reconciliation, compliance) |
| `payments-change-impact` | Given a change, lists affected obligations, rules, rails, products and controls from the register |
| `idempotency-and-duplicate-review` | Reviews a design or PR against `PAT-PAY` idempotency and duplicate-detection patterns |
| `reconciliation-runbook` | Drafts or updates a reconciliation and recovery runbook for a flow |
| `legacy-rule-extraction` | For modernization: extracts candidate rules from legacy code with evidence, as `proposed` |

Your organization's existing standards, security and governance skills stay in the enterprise
tier; domain skills build on them rather than repeating them.

## 5. Sensitive data rules for payments context

Never place in any tier: real account numbers, names, addresses, tax IDs, real transaction
IDs or UETRs from production, production message payloads, sanctions hit details, SAR-related
information, credentials, keys, certificates or internal hostnames marked restricted. Use
clearly synthetic examples (for example, reserved test routing numbers from scheme test
guides and obviously fake names).
