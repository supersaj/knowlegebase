# Governance and Controls

## 1. Ownership (RACI)

| Knowledge | Accountable | Approves changes | Consulted |
|---|---|---|---|
| Product Context standard, schemas, ID rules | Enterprise architecture | Architecture review board | Security, risk |
| AI usage and data-handling policy for context | CISO / AI governance | Policy owners | Legal, compliance |
| Domain obligations register | Domain architect + compliance liaison | Compliance | Legal, operations |
| Domain rules, mappings, patterns, glossary | Payments domain architects | Domain CODEOWNERS | Product architects |
| Personas, journeys, use cases, pain points | Product owner | Product CODEOWNERS (business) | UX research, operations, support |
| Product capabilities, business rules | Product owner | Product CODEOWNERS (business + architecture) | Operations |
| Quality attributes (NFRs) | Product architect | Product CODEOWNERS (architecture) | SRE, operations |
| Product architecture model, ADRs | Product architect | Product CODEOWNERS | Domain architects for pattern deviations |
| Runbooks | Product operations lead | Operations CODEOWNERS | SRE |
| Skills (any tier) | Tier owner | Tier CODEOWNERS + security review for scripts | Platform team |

Every `owner` value in front matter must resolve to a CODEOWNERS entry. Orphaned knowledge
is a quality-gate failure.

## 2. Approval and segregation of duties

- Changes to `product-context/`, `architecture/decisions/`, `obligations/`, `rules/` and skills
  require CODEOWNER review through a pull request.
- An agent may author a PR. It may not approve it, and the human who prompted the agent should
  not be the sole approver for rule, obligation or ADR changes.
- `status: proposed` → `active` happens only in a reviewed commit. The validator rejects
  `active` artifacts whose provenance is `ai-draft` or `extracted` without `verified_by`.
- Git history is the audit trail. Do not squash away review evidence for these folders.

## 3. Data handling

- Classify every artifact. `restricted` content does not enter the context layer; link to the
  controlled system instead, and let the agent retrieve it only through an entitled MCP/API call.
- Search and RAG indexes inherit the access controls of their sources. An index that lets a
  user retrieve content they could not open directly is a data-leak path.
- Secrets scanning and sensitive-data scanning run on context repos exactly as on code.
- Agent memory and chat transcripts are not a place to store product knowledge. Anything worth
  keeping goes through promotion.

## 4. Skill supply chain

Independent audits in 2026 found prompt injection in a large share of publicly shared skills.
Treat skills like code dependencies:

- Only install skills from the enterprise or domain tier, or from vetted sources pinned by version.
- Review `scripts/` and any network or shell access in every skill before approval.
- Record each skill in the catalog with owner, lifecycle and source location (Backstage supports
  an `AiResource` kind for skills and rules, and an `mcp-server` API type).
- Re-review on every version change.

## 5. MCP servers

- Register approved MCP servers in the catalog with owner, scopes and data classification.
- Prefer read-only scopes for context retrieval; write actions need their own approval path.
- Use per-user identity so entitlements and audit logs reflect the real requester.

## 6. Regulatory touchpoints to align with (confirm with risk and compliance)

- **Change management / SOX ITGC**: agent-authored changes follow the same review, approval and
  evidence rules as human changes.
- **Model risk management**: if agents make or materially support decisions in production
  processes, coordinate with the bank's model risk function (US banks commonly follow SR 11-7 /
  OCC 2011-12 style guidance). Design-time coding agents usually fall under software change
  controls, but confirm the classification.
- **Records retention**: ADRs, obligations and promotion PRs may be records; follow the retention schedule.
- **Third-party risk**: AI vendors and hosted MCP servers go through vendor risk review.

## 7. Conflict handling

When the validator, a review or an agent finds conflicting sources:
1. Apply the precedence order in `SKILL.md`.
2. Open an issue labelled `context-conflict`, owned by the accountable owner of the higher-precedence artifact.
3. Agents working on the affected area must cite the conflict and not silently choose.
