# Quality, Evaluation and Rollout

## 1. Assessment scorecard (Mode A / Mode E)

Score each dimension 0 to 3 (0 absent, 1 ad hoc, 2 defined, 3 enforced in CI or process).

| Dimension | 3 looks like |
|---|---|
| Identity | `product.yaml` complete, domain version pinned, catalog entry exists |
| Baseline coverage | Capabilities, rules, architecture model, ADRs and runbooks exist for all critical flows |
| Single source | No duplicated rules or architecture copies; SDLC artifacts cite IDs |
| Ownership | Every artifact owner resolves to CODEOWNERS |
| Freshness | No overdue `review_by` on active artifacts in critical flows |
| Provenance | AI-drafted or extracted artifacts are verified before activation |
| Traceability | Obligation → rule → component → test chain exists for regulated flows |
| Promotion loop | Every closed epic has a promotion PR or explicit "none" note |
| Agent usability | `AGENTS.md` within budget, commands verified, golden-set score tracked |
| Safety | No sensitive data findings; skills and MCP servers approved |

Report blockers first, then the three to five actions with the highest expected effect on the
golden-set score.

## 2. CI gates (knowledge as code)

Run on every PR that touches context folders:

| Check | Tool | Severity |
|---|---|---|
| Front matter schema, required fields, enums | `scripts/validate_context.py` | Error |
| Unique IDs, ID format, file name matches ID | validator | Error |
| Supersession integrity (`superseded` needs a valid `superseded_by`) | validator | Error |
| Relations point to known IDs (product + domain) | validator | Error for rules/ADRs, warning otherwise |
| AI-drafted or extracted artifacts active without `verified_by` | validator | Error |
| `restricted` classification present | validator | Error |
| Overdue `review_by` | validator | Warning (error for obligations) |
| `AGENTS.md` over line budget | validator | Warning |
| INDEX.md regenerated | validator `--write-index` | Error if stale |
| Secrets / sensitive data scan | existing bank scanners | Error |
| Link check, diagram render | standard tools | Warning |
| Architecture fitness functions | ArchUnit or equivalent | Error for accepted-ADR violations |

## 3. Golden question set (Mode F)

`evaluation/golden-questions.yaml`:

```yaml
product: PMTHUB
version: 1
questions:
  - id: GQ-001
    task: "Add support for an additional status reason on outbound RTP rejects."
    category: change-impact        # lookup | change-impact | design | troubleshooting | compliance
    expected_sources: [BR-PMTHUB-042, OBL-PAY-011, messages/code-sets/status-reasons.yaml]
    expected_facts:
      - "Reject handling must follow BR-PMTHUB-042"
      - "Mapping lives in the domain repo, not the product"
    must_not_use: [BR-PMTHUB-017]  # superseded
  - id: GQ-002
    task: "Who approves a change to the reconciliation cut-off logic?"
    category: lookup
    expected_sources: [product.yaml, CODEOWNERS]
```

Aim for 20 to 40 questions per product across categories, written by engineers from real
tickets and incidents. Include questions whose correct answer is "this is not documented".

## 4. Metrics

| Metric | Definition | Starting target |
|---|---|---|
| Retrieval accuracy | Share of questions where every expected source was cited | ≥ 80% |
| Answer correctness | Share with all expected facts right (human or rubric graded) | ≥ 80% |
| Stale-source hits | Share citing superseded/deprecated artifacts without caveat | ≤ 2% |
| Decision adherence | Sampled agent designs/PRs that respect active ADRs and rules | ≥ 95% |
| Promotion coverage | Closed epics with promotion PR or "none" note | 100% |
| Duplication | Conflicting-source issues open | Trending down |
| Freshness | Active artifacts past `review_by` in critical flows | 0 |
| Rework | Review comments citing missing or wrong context (sampled) | Trending down |

Document count and page count are not success measures.

## 5. Rollout phases (summary)

The full implementation plan is maintained separately. Summary:

| Phase | Scope | Exit criteria |
|---|---|---|
| 0. Mobilize | Approve standard and architecture model format, define graph schema v1, pick 2 pilots, set up repos | Standard and schema approved |
| 1. Assess and measure | Mode A on pilots; golden questions; baseline score | Baseline recorded |
| 2. Domain tier seed | Glossary, message catalog, code sets, obligations, controls, 2-3 patterns | Domain v0.1 released and pinned |
| 3. Product baselines | Mode B: product.yaml, overview, personas, journeys, pain points, rules, current C4 model (+ interim/target where migrating), ADRs, runbooks; graph v0 in CI | Validator and model validation clean; score improved |
| 4. SDLC wiring | BMAD and non-BMAD touchpoints: read baseline, readiness check, promotion, go-live state update | First promotion and state update merged |
| 5. Skills and MCP | 5-10 skills; read-only MCP for Jira, Confluence, Git, SonarQube, catalog; graph query tool | Live-state and multi-hop questions pass |
| 6. Evaluate and decide | Re-score; go/no-go; graph database decision | Scale-out approved |
| 7. Scale out | Waves of 3-5 products; department landscape; enterprise graph | Department scorecard published |
