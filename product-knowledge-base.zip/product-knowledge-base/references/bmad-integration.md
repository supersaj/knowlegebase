# SDLC Framework Integration (BMAD first, then others)

The product knowledge base never replaces the framework. It gives the framework a trusted
baseline to read, and receives durable knowledge back through promotion.

BMAD changes quickly (the v6 line has consolidated and renamed several skills and workflows
during 2026). Before configuring anything, check the installed version under `_bmad/` and
the release notes, and map by **artifact role**, not by workflow name.

## 1. BMAD artifact map

| BMAD artifact (role) | Typical location | Classification | Reads from baseline | Gives back to baseline |
|---|---|---|---|---|
| Configuration, agents, workflows | `_bmad/` | Framework, not knowledge | — | — |
| Product brief, PRD | `_bmad-output/planning-artifacts/` | Delta | Overview, `PER-*`, `JRN-*`, open `PAIN-*`, `UC-*`, `CAP-*`, `BR-*`, `NFR-*`, domain obligations | Candidate use cases, capabilities, rules; target journeys; pain points marked planned |
| UX design | `_bmad-output/planning-artifacts/` | Delta | Capabilities, glossary | Rarely; glossary terms |
| Architecture document | `_bmad-output/planning-artifacts/` | Delta (change design) | Current and target C4 model, active ADRs, NFRs, domain patterns | A proposed interim or target model plus ADRs |
| Epics and stories | planning and implementation artifacts | Delta | Rule and ADR IDs cited in acceptance criteria | Links (`related_sdlc`) only |
| Sprint status | `_bmad-output/implementation-artifacts/` | Live state of the change | — | Never |
| Project context (AGENTS.md block in current releases; `project-context.md` in earlier v6) | `AGENTS.md` or `_bmad-output/` | Always-on instructions | Must not contradict baseline | — |
| Retrospective | per epic | Promotion trigger | — | Runs Mode D |
| Test design / traceability (Test Architect module, if used) | per epic | Delta plus evidence | `BR-*` IDs | `verified_by_tests` links |

## 2. Rules for BMAD products

1. **The baseline is the input, not the output.** Configure BMAD so the PM, architect and
   developer roles load `product.yaml`, `product-context/INDEX.md`, the active ADR list and
   relevant domain obligations at the start of planning. Use BMAD's supported customization
   mechanism for the installed version (agent customization files, workflow configuration,
   or a custom module). Do not edit BMAD core files; upgrades overwrite them.
2. **Cite IDs, don't restate.** PRDs, architecture docs and stories reference `BR-*`, `ADR-*`,
   `OBL-*` and `CAP-*` by ID. Restating a rule's text inside a story creates a second copy that drifts.
3. **Architecture document is a change design, expressed as architecture states.**
   - Greenfield: the accepted architecture becomes `target.architecture.json` (plus ADRs) at the
     readiness gate, and `current.architecture.json` at first go-live.
   - Brownfield / modernization: capture `current.architecture.json` first (Mode B). Each BMAD
     architecture document proposes the next `transition-NN.architecture.json` (and target
     changes via ADR). At go-live the delivered transition becomes current.
4. **Add a baseline check to the readiness gate.** Before implementation starts, verify the plan
   does not contradict active ADRs, active business rules or domain obligations, and that the
   proposed architecture model passes validation against its domain patterns (`calm validate`). Contradictions
   need a new ADR (superseding) or a plan change, decided by humans.
5. **Promote at the retrospective.** The epic retrospective is the natural gate for Mode D.
   Output: a promotion PR, or an explicit "no promotable knowledge" note.
6. **Archive completed deltas.** BMAD's own guidance warns that completed epics and stories left
   in planning or implementation folders get treated as current requirements. After promotion,
   move them to an archive location that agents do not search by default.
7. **Coexist in AGENTS.md.** Current BMAD releases maintain a verified project-context block in
   `AGENTS.md`. Keep it inside its own markers; the product-context block sits beside it.
   Neither tool edits the other's block.
8. **Do not use generated documentation dumps as baseline.** Both BMAD's current direction and
   independent research moved away from large generated repository overviews for agent context.
   If a code-to-docs generator is used for brownfield discovery, treat its output as evidence
   for drafting `proposed` artifacts, not as the baseline itself.

## 3. Modernization specifics

Modernization is the near-term priority and the riskiest case, because the legacy system's
behaviour is often the only specification.

- Extract business rules from legacy code and documents as `proposed` with `provenance.method:
  extracted` and evidence (program, paragraph or module, test case). Business and operations
  owners verify them before they become `active`.
- Record behavioural equivalence decisions explicitly as ADRs (what will intentionally differ in
  the new platform, and why).
- Keep `current`, `transition-NN` and `target` model files with `states.yaml` (format: `calm-conventions.md`).
  Each transition becomes current only when its slice goes live and its exit criteria are met.
- Parallel-run and reconciliation results are evidence (`evidenced_by`) for the rules they prove.

## 4. Other frameworks (generic mapping)

| Framework | Delta (framework-owned) | Potential overlap with baseline | Resolution |
|---|---|---|---|
| GitHub Spec Kit | `specs/NNN-*/spec.md`, `plan.md`, `tasks.md` | `.specify/memory/constitution.md` | Constitution references enterprise and domain standards by ID and adds only project-specific principles |
| OpenSpec | `openspec/changes/` | `openspec/specs/` is itself a current-behaviour baseline | Treat `openspec/specs/` as the authoritative behaviour spec; `product.yaml` points to it; do not duplicate into `product-context/` |
| Kiro | `.kiro/specs/` | `.kiro/steering/` | Steering files point to `AGENTS.md` and IDs; no restated rules |
| Scrum / Jira-only | Jira epics and stories | Confluence pages | Jira stays delta; durable Confluence content migrates to the baseline or is linked as `provenance.sources` |

In every case, record the mapping under `sdlc:` in `product.yaml` so agents can find both
the delta and the baseline.
