---
id: PAIN-<PRODUCT>-<NNN>
type: pain-point
title: <the problem in a few words, from the user's side>
status: proposed
owner: team:<owning-team>
version: 1
review_by: <YYYY-MM-DD>        # 6 months while open
classification: internal
severity: <low | medium | high | critical>
resolution: open               # open | planned | mitigated | resolved
evidence:                      # links only; never paste customer data or transcripts
  - <research note, complaint trend, incident, metric dashboard>
provenance:
  method: <human | ai-draft | extracted>
  sources: [<where this was summarized from>]
  verified_by:
  verified_at:
relations:
  affects: [<JRN-...>, <UC-...>, <PER-...>]
  related_sdlc: [<epic that addresses it, once planned>]
tags: []
---

## Problem

<What goes wrong, in the persona's terms. One or two sentences.>

## Impact

<Time lost, cost, risk, customer or operator effect. Numbers where known, with their source.>

## Frequency

<How often, for whom.>

## Current workaround

<What people do today, or "none".>
