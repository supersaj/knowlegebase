---
id: UC-<PRODUCT>-<NNN>
type: use-case
title: <verb phrase, e.g. "Release a payment held for repair">
status: proposed
owner: team:<owning-team>
version: 1
review_by: <YYYY-MM-DD>
classification: internal
persona: PER-<PRODUCT>-<NNN>
provenance:
  method: <human | ai-draft | extracted>
  sources: [<where this was derived from>]
  verified_by:
  verified_at:
relations:
  implements: [<CAP-...>]
  depends_on: [<BR-...>, <NFR-...>]
tags: []
---

## Goal

<What the persona wants to achieve.>

## Trigger and preconditions

<What starts it; what must already be true.>

## Main flow

1. <step>
2. <step>

## Alternate and failure flows

- <condition> → <what happens>

## Postconditions

<What is true afterwards, including audit and notifications.>
