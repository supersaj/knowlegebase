# Knowledge Promotion — <epic / feature reference>

Use as the PR description for a promotion PR (Mode D).

## Source change
- SDLC artifacts: <PRD / epic / stories / spec paths or links>
- Merged code: <PR links>
- Incidents or review notes consulted: <links or "none">

## Candidates

| # | Kind | Proposed artifact | New or update | Evidence | Owner to approve |
|---|---|---|---|---|---|
| 1 | business rule | BR-<PRODUCT>-<NNN> | update v2 → v3 | <link> | team:<...> |
| 2 | decision | ADR-<PRODUCT>-<NNN> | new | <link> | team:<...> |

Or: **No promotable knowledge.** Reason: <e.g. change was purely internal refactoring>.

## Checks
- [ ] Searched for existing artifacts before creating new ones (no near-duplicates)
- [ ] Domain-level knowledge proposed to the domain repo, not copied here
- [ ] All new or changed artifacts are `status: proposed` with evidence in `provenance.sources`
- [ ] Superseded artifacts updated with `superseded_by`
- [ ] Contradictions with the baseline listed below
- [ ] No sensitive data; examples are synthetic
- [ ] `validate_context.py` passes and `INDEX.md` regenerated
- [ ] Completed SDLC artifacts ready to archive after merge

## Contradictions found
<List any conflicts with active rules, ADRs or obligations, or "None.">
