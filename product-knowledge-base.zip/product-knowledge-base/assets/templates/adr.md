---
id: ADR-<SCOPE>-<NNN>
type: adr
title: <decision in a few words>
status: proposed          # becomes active when accepted; immutable after that
owner: team:<owning-team>
version: 1
review_by: <YYYY-MM-DD>   # relevance check, typically 24 months
classification: internal
decision_date: <YYYY-MM-DD>
deciders: [<team:... or role:...>]
supersedes: []
superseded_by:
provenance:
  method: <human | ai-draft>
  sources: [<design doc, PR, meeting record>]
  verified_by:
  verified_at:
relations:
  applies_to: [<component:...>]
  governed_by: [<OBL-PAY-... or PAT-PAY-...>]
  implements: [<CAP-...>]
  related_sdlc: [<architecture doc / epic reference>]
tags: []
---

## Context and problem

<What forces are at play? What problem must be solved now?>

## Decision drivers

- <e.g. settlement finality, latency budget, idempotency, reconciliation, sanctions screening placement, operational resilience, cost>

## Considered options

1. <Option A>
2. <Option B>
3. <Option C>

## Decision

Chosen option: <option>, because <justification tied to drivers>.

## Consequences

- Positive: <...>
- Negative: <...>
- Follow-ups: <new rules, runbooks, fitness functions, migrations>

## Compliance and risk impact

<Obligations or controls affected; "none" if none.>

## Links

<Related ADRs, patterns, contracts.>
