# AGENTS.md

<!-- BEGIN product-context (owner: product architect; keep this block under ~80 lines) -->
## Product
<Product name> (`<PRODUCT-ID>`): <one sentence on what it does and for whom>.
Identity, owners, dependencies and SDLC mapping: `product.yaml`.
Knowledge index (generated): `product-context/INDEX.md`.

## Commands (verified <YYYY-MM-DD>)
- Build: `<command>`
- Unit tests: `<command>`
- Integration tests: `<command>`
- Lint and context validation: `<command>` and `python <path>/validate_context.py --root .`

## Hard constraints
- Follow active ADRs in `architecture/decisions/` and active rules in `product-context/business-rules/`. If code contradicts them, stop and report the drift.
- Payments rules, message mappings, code sets and obligations come from the payments domain context `<repo>@<version>`. Reference them by ID; never copy them here.
- Never put real customer data, account numbers, production messages or secrets in code, tests, fixtures or docs. Use synthetic data.
- Live facts (deployed version, incidents, ticket status) come from MCP tools, not from docs.
- Every change must be idempotent-safe on payment paths; see `PAT-PAY-001`.

## Architecture
- C4 model in `architecture/model/`: `current.architecture.json` is what runs in production; `states.yaml` lists interim and target states.
- Users and problems: `product-context/personas/`, `journeys/`, `use-cases/`, `pain-points/`.
- Troubleshooting and operations: use current. Implementing a slice: diff current against the transition state it delivers. Design: use target.

## Where things go
- Changing behaviour? Work in the SDLC framework (`<e.g. _bmad-output/>`), cite `BR-*` / `ADR-*` IDs.
- Found a new durable rule or decision? Draft it as `status: proposed` and flag it for promotion; do not mark it active.

## Skills
Product skills: `.agents/skills/`. Domain and enterprise skills are installed from their repos.
<!-- END product-context -->

<!-- Other tools (for example BMAD's project-context block) keep their own marked sections below. -->
