---
id: PER-<PRODUCT>-<NNN>
type: persona
title: <role name, e.g. "Payments repair operator">
status: proposed
owner: team:<owning-team>
version: 1
review_by: <YYYY-MM-DD>
classification: internal
provenance:
  method: <human | ai-draft | extracted>
  sources: [<research, org charts, support data>]
  verified_by:
  verified_at:
tags: []
---

## Who they are

<Role, organization type (customer, internal operator, partner), expertise. An archetype, never a real person.>

## Goals

- <goal>

## Context of use

<Channels, volumes, time pressure, tools they use alongside ours.>

## What good looks like

<How they judge the product.>
