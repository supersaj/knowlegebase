---
id: BR-<PRODUCT>-<NNN>
type: business-rule
title: <short imperative title>
status: proposed
owner: team:<owning-team>
version: 1
review_by: <YYYY-MM-DD>
classification: internal
scope: "<rail, direction, payment type, channel>"
effective_from: <YYYY-MM-DD>
effective_to:
rule_source: <policy | regulation | scheme-rule | product-decision | contract>
supersedes: []
superseded_by:
provenance:
  method: <human | ai-draft | extracted>
  sources:
    - <path, PR, policy reference, legacy module>
  verified_by:
  verified_at:
relations:
  implements: [<CAP-...>]
  governed_by: [<OBL-PAY-...>]
  applies_to: [<component:...>]
  decided_in: []
  verified_by_tests: [<test path or id>]
  related_sdlc: [<epic / PRD reference>]
tags: []
---

## Rule

When <trigger>, the system shall <required response>.

## Rationale

<Why this rule exists. Reference the obligation or decision, not its full text.>

## Exceptions

<Exhaustive list, or "None.">

## Examples

<Synthetic examples only. No real customer or production data.>

## Verification

<Which tests or controls prove the rule, and what they assert.>
