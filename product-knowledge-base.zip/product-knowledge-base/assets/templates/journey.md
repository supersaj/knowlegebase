---
id: JRN-<PRODUCT>-<NNN>
type: journey
title: <persona> <goal>, e.g. "Treasury analyst sends an urgent wire"
status: proposed
owner: team:<owning-team>
version: 1
review_by: <YYYY-MM-DD>
classification: internal
persona: PER-<PRODUCT>-<NNN>
state: current                 # current | target (a target journey names the state or ADR that delivers it)
provenance:
  method: <human | ai-draft | extracted>
  sources: [<research, process maps, support data>]
  verified_by:
  verified_at:
relations:
  involves: [<other PER-... taking part>]
  depends_on: [<UC-...>, <BR-...>]
tags: []
---

## Goal

<What the persona is trying to achieve and what success looks like to them.>

## Stages

| # | Persona does | Channel / touchpoint | System behaviour (C4 elements) | Pain points |
|---|---|---|---|---|
| 1 | <action> | <portal, API, file, phone> | <element IDs> | <PAIN-... or none> |
| 2 | | | | |

## Moments that matter

<The one or two stages where the experience is won or lost.>
